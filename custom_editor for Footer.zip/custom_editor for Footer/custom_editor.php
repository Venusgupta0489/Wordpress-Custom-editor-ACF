
<!-- heading Code -->
<?php if (get_field('heading_text')) { ?>
<div class="headings">
	<<?= get_field('heading') ?>><?= get_field('heading_text') ?></<?= get_field('heading') ?>>
</div>
<?php  } ?>


<!-- Description Code -->
<?php if (get_field('description')) { ?>
<div class="description">
	<p><?= get_field('description') ?></p>
</div>
<?php  } ?>

<!-- List Description  Code -->
<?php if (get_field('list_box_with_link')) { ?>
	<ul class="list_box_with_link">
		<?php foreach (get_field('list_box_with_link') as  $value) { ?>
			<li><a target="<?= $value['text']['target'] ?>" href="<?= $value['text']['url'] ?>"><?= html_entity_decode($value['text']['title']) ?></a></li>
		<?php } ?>
	</ul>
<?php } ?>


<!-- ICon Code -->

<?php if (get_field('icon_list_with_link')) { ?>
	<ul class="listitem">
		<?php foreach (get_field('icon_list_with_link') as  $value) { ?>
			<li>
				<a target="<?= $value['icon']['target'] ?>" href="<?= $value['icon']['url'] ?>"><?php echo html_entity_decode($value['icon']['title']); ?></a>
			</li>
		<?php } ?>	
	</ul>
<?php } ?>




	
